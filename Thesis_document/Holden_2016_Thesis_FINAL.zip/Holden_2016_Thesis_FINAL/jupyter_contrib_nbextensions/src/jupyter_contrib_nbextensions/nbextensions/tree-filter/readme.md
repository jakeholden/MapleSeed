Description
===========
An extension that allows you to filter by filename in the Jupyter notebook file tree (aka dashboard) page.
Based on https://github.com/jdfreder/jupyter-tree-filter.git

![](demo.gif)

