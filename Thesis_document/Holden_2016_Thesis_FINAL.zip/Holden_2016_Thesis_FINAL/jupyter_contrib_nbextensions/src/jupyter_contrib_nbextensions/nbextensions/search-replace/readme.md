Description
===========
This extension provides a notebook-wide search & replace toolbar.

![before](icon.png)

It uses the codemirror `search` and `searchcursor` add ons and allows search and replace operation through the
whole notebook.   
  
Alternatively, a 'Find an Replace' feature is available in the Jupyter notebook itself.
 
