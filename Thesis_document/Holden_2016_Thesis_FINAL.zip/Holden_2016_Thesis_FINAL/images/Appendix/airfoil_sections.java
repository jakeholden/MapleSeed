// STAR-CCM+ macro: airfoil_sections.java
// Written by STAR-CCM+ 10.04.011
package macro;

import java.util.*;

import star.common.*;
import star.base.neo.*;
import star.vis.*;
import star.flow.*;
import star.motion.*;

public class airfoil_sections extends StarMacro {

  public void execute() {
    execute0();
  }

  private void execute0() {

    Simulation simulation_0 =
      getActiveSimulation();

    Scene scene_0 =
      simulation_0.getSceneManager().getScene("Scalar_seed_x_section");

    CurrentView currentView_0 =
      scene_0.getCurrentView();

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\PS_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    ScalarDisplayer scalarDisplayer_1 =
      ((ScalarDisplayer) scene_0.getDisplayerManager().getDisplayer("Scalar 1"));

    PrimitiveFieldFunction primitiveFieldFunction_0 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("Velocity"));

    UserRotatingReferenceFrame userRotatingReferenceFrame_0 =
      ((UserRotatingReferenceFrame) simulation_0.get(ReferenceFrameManager.class).getObject("Rotating"));

    VectorComponentFieldFunction vectorComponentFieldFunction_0 =
      ((VectorComponentFieldFunction) primitiveFieldFunction_0.getFunctionInReferenceFrame(userRotatingReferenceFrame_0).getComponentFunction(0));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(vectorComponentFieldFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    VorticityVectorFunction vorticityVectorFunction_0 =
      ((VorticityVectorFunction) simulation_0.getFieldFunctionManager().getFunction("VorticityVector"));

    VectorMagnitudeFieldFunction vectorMagnitudeFieldFunction_0 =
      ((VectorMagnitudeFieldFunction) vorticityVectorFunction_0.getMagnitudeFunction());

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(vectorMagnitudeFieldFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Vorticity_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    VectorMagnitudeFieldFunction vectorMagnitudeFieldFunction_1 =
      ((VectorMagnitudeFieldFunction) primitiveFieldFunction_0.getFunctionInReferenceFrame(userRotatingReferenceFrame_0).getMagnitudeFunction());

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(vectorMagnitudeFieldFunction_1);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(vectorComponentFieldFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Vi_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.009204846673213835, -0.0019281843372406593}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0019281843372406593}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.027081476912435225, 0);

    PrimitiveFieldFunction primitiveFieldFunction_1 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("TangentialVelocity"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_1);

    currentView_0.setInput(new DoubleVector(new double[] {-0.0051036912572137265, 0.022442904167377348, -0.0017894937354096677}), new DoubleVector(new double[] {-0.0051036912572137265, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.030537303386641786, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Vtan_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_2 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("TotalPressure"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_2);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_2.getFunctionInReferenceFrame(userRotatingReferenceFrame_0));

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_3 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("TurbulentKineticEnergy"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_3);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\TKE_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_4 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("TurbulentViscosityRatio"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_4);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    TotalPressureCoefficientFunction totalPressureCoefficientFunction_0 =
      ((TotalPressureCoefficientFunction) simulation_0.getFieldFunctionManager().getFunction("TotalPressureCoefficient"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(totalPressureCoefficientFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_5 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("RelativeTotalPressure"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_5);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_6 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("RadialVelocity"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_6);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Vradial_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_7 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("RadialCoordinate"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_7);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    QcriterionFunction qcriterionFunction_0 =
      ((QcriterionFunction) simulation_0.getFieldFunctionManager().getFunction("Qcriterion"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(qcriterionFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Qcrit_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_8 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("Pressure"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_8);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PressureCoefficientFunction pressureCoefficientFunction_0 =
      ((PressureCoefficientFunction) simulation_0.getFieldFunctionManager().getFunction("PressureCoefficient"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(pressureCoefficientFunction_0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    Legend legend_0 =
      scalarDisplayer_1.getLegend();

    legend_0.updateLayout(new DoubleVector(new double[] {0.845015706806283, 0.15559201773835996}), 0.04400000000000004, 0.5999999999999996, 1);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Pressure_Coeff_95%.png"), 1, 956, 452);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_9 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("Density"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_9);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_10 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("AbsoluteTotalPressure"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_10);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.03612891291876971, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.034110068604660884, 0);

    PrimitiveFieldFunction primitiveFieldFunction_11 =
      ((PrimitiveFieldFunction) simulation_0.getFieldFunctionManager().getFunction("AxialVelocity"));

    scalarDisplayer_1.getScalarDisplayQuantity().setFieldFunction(primitiveFieldFunction_11);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.05097577428122699, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.037985877164781995, 0);

    currentView_0.setInput(new DoubleVector(new double[] {-0.004948774305858227, 0.05097577428122699, -0.0017894937354096677}), new DoubleVector(new double[] {-0.004948774305858227, -0.09453478003243268, -0.0017894937354096677}), new DoubleVector(new double[] {-1.0, 0.0, 0.0}), 0.037985877164781995, 0);

    scene_0.printAndWait(resolvePath("C:\\Users\\Admin\\Dropbox\\MapleSeed\\Thesis\\CFD_Simulation\\RANS\\Image_dump\\Vaxial_95%.png"), 1, 956, 452);
  }
}
